package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.TeamCreateRequest;
import com.example.demo.service.PagerService;

@RestController
public class Controller {
	@Autowired
	PagerService pagerService;
	
	
	@PostMapping("/createTeam")
	public String createTeam(@RequestBody TeamCreateRequest teamCreateRequest) {
		return pagerService.createTeam(teamCreateRequest);
	}
	
	@GetMapping("/alert/{teamId}")
	public String alertTeam(@PathVariable long teamId) {
		return pagerService.alertTeam(teamId);
	}
	
}
