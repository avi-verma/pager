package com.example.demo.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.TeamCreateRequest;
import com.example.demo.entity.Developer;
import com.example.demo.entity.Team;
import com.example.demo.repos.DeveloperRepo;
import com.example.demo.repos.TeamRepository;

@Service
public class PagerService {

	@Autowired
	DeveloperRepo developerRepo;
	
	@Autowired
	TeamRepository teamRepository;
	

	@Transactional
	public String createTeam(TeamCreateRequest teamCreateRequest) {
		
		//System.out.println(teamCreateRequest.getDevelopers());
		teamRepository.save(teamCreateRequest.getTeam());
		developerRepo.saveAll(teamCreateRequest.getDevelopers());
		return "SUCCESS";
		// TODO Auto-generated method stub
		
	}

	public String alertTeam(long teamId) {
		// TODO Auto-generated method stub
		Team team=teamRepository.getById(teamId);
		Optional<Developer> dev=team.getDevelopers().stream().findAny();
		//notification EndPoints= > call notification client with the developer details
		
		return "ALERT_SENT_SUCCESSFULLY";
	}
	  
}
