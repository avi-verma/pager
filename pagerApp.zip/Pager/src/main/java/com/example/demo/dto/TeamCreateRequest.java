package com.example.demo.dto;

import java.util.List;

import com.example.demo.entity.Developer;
import com.example.demo.entity.Team;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TeamCreateRequest {
	
	private Team team;
	private List<Developer> developers;
}
